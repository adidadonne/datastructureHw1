#ifndef LIST_H
#define LIST_H
#include <iostream>
using namespace std;




class listNode{

public:
    int key;
    void* element;
    listNode* prev;
    listNode* next;
    listNode() : key(), element(), prev(nullptr), next(nullptr){};
    listNode(int key, void* element, listNode* prev = nullptr, listNode* next = nullptr) : key(key), element(element), prev(prev), next(next) {};
    ~listNode() = default;
};

class list {
    listNode* head;
    listNode* tail;
    int size;
//public:


public:
    list() {
        head = new listNode();
        if ( head == nullptr ){
            throw allocationError();
        }

        tail = head;
        size = 0;
    }

    list(int key, void* element); // constructor
    ~list();
    int getSize();
    listNode *getHead() ;
    listNode *getTail() ;
    void setTail(listNode *tail);
    void insertLast(int key, void *element);
    void insertNode(listNode *currentNode, int key, void* element);
    void removeNode( listNode* currentNode); //Removing Node from the list
    listNode *popNode(listNode *currentNode);
    bool isEmpty();
    listNode *find(int key) ;
    class allocationError : public exception {
    public :
        const char* what() const noexcept override { return "Memory allocation error"; }
    };

};



/*****************************************************************************/
/**-----------------Implementation of List methods--------------------------**/
/*****************************************************************************/

list::list(int key, void* element) {
    head = new listNode(key, element);
    if ( head == nullptr ){
        throw allocationError();
    }

    tail = head;
    size = 0;
}

list::~list() {

    listNode* tmpHead;
    tail = nullptr;
    while(head != nullptr) {
        tmpHead = this->head->next;
        delete head;
        head = tmpHead;
    }

}


// Inserting the wanted node as the next node.

void list::insertNode(listNode *currentNode, int key, void* element) {
    if(!currentNode) {
        return;
    }

    listNode* newNode = new listNode(key, element, currentNode, currentNode->next);
    if( !newNode ){
        throw allocationError();
    }

    if (currentNode->next){
        currentNode->next->prev = newNode;
    }
    currentNode->next = newNode;

    if(tail == currentNode){
        tail = newNode;
    }
    size++;

}


void list::removeNode( listNode *currentNode) {
    if(!currentNode) {
        return;
    }

    if (currentNode->next){
        currentNode->next->prev = currentNode->prev;
    }

    currentNode->prev->next = currentNode->next;

    if(currentNode == tail){
        tail = tail->prev;
    }
    delete currentNode;
//    *currentNode = nullptr;
    size--;
}


listNode *list::popNode(listNode *currentNode) {
    if(!currentNode) {
        return nullptr;
    }

    if (currentNode->next){
        currentNode->next->prev = currentNode->prev;
    }

    currentNode->prev->next = currentNode->next;

    if(currentNode == tail){
        tail = tail->prev;
    }

    return currentNode;

}


listNode *list::getHead()  {
    return head;
}


listNode *list::getTail()  {
    return tail;
}


void list::setTail(listNode *tail) {
    list::tail = tail;
}


void list::insertLast(int key, void *element) {
    insertNode(tail, key, element);

}


bool list::isEmpty() {
    return head == tail;
}


listNode *list::find(int key) {

    listNode* tmp = head;
    while(tmp != nullptr) {
        if (tmp->key == key){
            return tmp;
        }
        tmp=tmp->next;
    }
    return nullptr;
}


int list::getSize() {
    return size;
}

/*****************************************************************************/
/**-------------End of Implementation of List methods-----------------------**/
/*****************************************************************************/

#endif //LIST_H